export const environment = {
  production: true,
  baseUrl:'https://damaanati.hackerkernel.co/api/',
  mapsKey:'AIzaSyA41ty7-oPxFl5U90GO1Cev9-nd2c3h5nc'
};